import { useState } from 'react'
import { useRouter } from 'next/router'
import { useSearchParams } from 'next/navigation'

export default function Password() {
  const [password, setPassword] = useState('')
  const router = useRouter()
  const searchParams = useSearchParams()
  const email = searchParams.get('email') || ''

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    alert(`Email: ${email}\nPassword: ${password}`)
    router.push('/')
  }

  return (
    <div className="bg-white shadow-lg rounded-xl p-8 max-w-md w-full">
      <h1 className="text-2xl font-semibold mb-6 text-center">Enter Password</h1>
      <p className="mb-4 text-gray-700 text-sm">for <strong>{email}</strong></p>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full border border-gray-300 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        <button
          type="submit"
          className="w-full bg-blue-600 text-white font-medium py-3 rounded-lg hover:bg-blue-700 transition"
        >
          Sign in
        </button>
      </form>
    </div>
  )
}
