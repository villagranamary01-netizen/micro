import { useState } from 'react'
import { useRouter } from 'next/router'

export default function Home() {
  const [email, setEmail] = useState('')
  const router = useRouter()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (email.trim()) {
      router.push(`/password?email=${encodeURIComponent(email)}`)
    } else {
      alert("Please enter your email or phone number.")
    }
  }

  return (
    <div className="bg-white shadow-lg rounded-xl p-8 max-w-md w-full">
      <h1 className="text-2xl font-semibold mb-6 text-center">Sign in</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="text"
          placeholder="Email or phone number"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full border border-gray-300 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        <button
          type="submit"
          className="w-full bg-blue-600 text-white font-medium py-3 rounded-lg hover:bg-blue-700 transition"
        >
          Next
        </button>
      </form>
    </div>
  )
}
